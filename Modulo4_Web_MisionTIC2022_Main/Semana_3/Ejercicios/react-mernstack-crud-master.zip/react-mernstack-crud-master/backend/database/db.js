module.exports = {
  mongoURI:
    "mongodb+srv://lmolero:12697883@cluster0.bpms5.mongodb.net/reactdb?retryWrites=true&w=majority",
  secretOrKey: "secret",
};
